﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace recipesMake
{
    public partial class ScaleRecipeWindow : Window
    {
        public string RecipeName { get; private set; }

        public ScaleRecipeWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            cmbRecipes.ItemsSource = recipes;
        }

        private void btnScale_Click(object sender, RoutedEventArgs e)
        {
            if (cmbRecipes.SelectedItem != null)
            {
                Recipe selectedRecipe = (Recipe)cmbRecipes.SelectedItem;
                double factor;
                if (double.TryParse(txtScaleFactor.Text, out factor) && factor > 0)
                {
                    selectedRecipe.ScaleRecipe(factor);
                    RecipeName = selectedRecipe.Name;
                    DialogResult = true;
                    Close();
                }
                else
                {
                    MessageBox.Show("Invalid scale factor. Please enter a valid positive number.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a recipe.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}