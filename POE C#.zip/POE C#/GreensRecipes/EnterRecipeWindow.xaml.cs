﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace recipesMake
{
    public partial class EnterRecipeWindow : Window
    {
        public Recipe Recipe { get; private set; }

        public EnterRecipeWindow()
        {
            InitializeComponent();
            Recipe = new Recipe();
        }

        private void btnAddIngredients_Click(object sender, RoutedEventArgs e)
        {
            int numIngredients;
            if (int.TryParse(txtNumIngredients.Text, out numIngredients) && numIngredients > 0)
            {
                for (int i = 0; i < numIngredients; i++)
                {
                    IngredientWindow ingredientWindow = new IngredientWindow();
                    if (ingredientWindow.ShowDialog() == true)
                    {
                        Recipe.AddIngredient(ingredientWindow.Ingredient.Name, ingredientWindow.Ingredient.Quantity,
                                             ingredientWindow.Ingredient.Unit, ingredientWindow.Ingredient.Calories,
                                             ingredientWindow.Ingredient.FoodGroup);
                        lstIngredients.Items.Add(ingredientWindow.Ingredient);
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid number of ingredients. Please enter a valid positive number.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnSaveRecipe_Click(object sender, RoutedEventArgs e)
        {
            Recipe.Name = txtRecipeName.Text;
            if (!string.IsNullOrEmpty(Recipe.Name) && Recipe.Ingredients.Count > 0)
            {
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Please enter a recipe name and at least one ingredient.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
