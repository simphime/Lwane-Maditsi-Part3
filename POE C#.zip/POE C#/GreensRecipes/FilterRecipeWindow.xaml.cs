﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace recipesMake
{
    /// <summary>
    /// Interaction logic for FilterRecipeWindow.xaml
    /// </summary>
    public partial class FilterRecipeWindow : Window
    {
        public List<Recipe> Recipes { get; set; }

        public FilterRecipeWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            Recipes = recipes;
            PopulateFoodGroups();
        }

        private void PopulateFoodGroups()
        {
            var foodGroups = Recipes
                .SelectMany(recipe => recipe.Ingredients)
                .Select(ingredient => ingredient.FoodGroup)
                .Distinct()
                .ToList();
            cmbFoodGroups.ItemsSource = foodGroups;
        }

        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            List<Recipe> filteredRecipes;

            if (!string.IsNullOrEmpty(txtIngredient.Text))
            {
                // Filter by ingredient name
                filteredRecipes = Recipes.Where(recipe => recipe.Ingredients.Any(ing => ing.Name.Contains(txtIngredient.Text))).ToList();
            }
            else
            {
                // Filter by selected food group
                var selectedFoodGroup = cmbFoodGroups.SelectedItem?.ToString();
                filteredRecipes = Recipes.Where(recipe => recipe.Ingredients.Any(ing => ing.FoodGroup == selectedFoodGroup)).ToList();
            }

            // Display filtered recipes in the ListBox
            lstFilteredRecipes.ItemsSource = filteredRecipes;
        }
    }
}
