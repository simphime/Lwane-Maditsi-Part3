﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace recipesMake
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnEnterRecipe_Click(object sender, RoutedEventArgs e)
        {
            EnterRecipeWindow enterRecipeWindow = new EnterRecipeWindow();
            if (enterRecipeWindow.ShowDialog() == true)
            {
                Recipe newRecipe = enterRecipeWindow.Recipe;
                recipes.Add(newRecipe);
                int totalCalories = newRecipe.CalculateTotalCalories();
                if (totalCalories > 300)
                {
                    MessageBox.Show($"Warning: Total calories of recipe '{newRecipe.Name}' exceed 300.", "Calorie Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                statusBarText.Text = $"Recipe '{newRecipe.Name}' added successfully.";
            }
        }

        private void btnDisplayRecipes_Click(object sender, RoutedEventArgs e)
        {
            txtOutput.Clear();
            if (recipes.Count == 0)
            {
                txtOutput.Text = "No recipes available.";
            }
            else
            {
                txtOutput.Text = "All Recipes:\n";
                foreach (var recipe in recipes.OrderBy(r => r.Name))
                {
                    txtOutput.Text += recipe.Name + "\n";
                }
            }
        }

        private void btnSelectRecipe_Click(object sender, RoutedEventArgs e)
        {
            SelectRecipeWindow selectRecipeWindow = new SelectRecipeWindow(recipes);
            if (selectRecipeWindow.ShowDialog() == true)
            {
                Recipe selectedRecipe = selectRecipeWindow.SelectedRecipe;
                txtOutput.Clear();
                txtOutput.Text = $"Selected Recipe:\n{selectedRecipe.Name}\n\nIngredients:\n";
                foreach (var ingredient in selectedRecipe.Ingredients)
                {
                    txtOutput.Text += $"{ingredient.Quantity} {ingredient.Unit} {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})\n";
                }
                txtOutput.Text += $"\nTotal Calories: {selectedRecipe.CalculateTotalCalories()}";
            }
        }

        private void btnScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            ScaleRecipeWindow scaleRecipeWindow = new ScaleRecipeWindow(recipes);
            if (scaleRecipeWindow.ShowDialog() == true)
            {
                statusBarText.Text = $"Recipe '{scaleRecipeWindow.RecipeName}' scaled successfully.";
            }
        }

        private void btnFilterRecipes_Click(object sender, RoutedEventArgs e)
        {
            FilterRecipeWindow filterRecipeWindow = new FilterRecipeWindow(recipes);
            filterRecipeWindow.ShowDialog(); // This will open the filter window modally
        }

        private void btnClearRecipes_Click(object sender, RoutedEventArgs e)
        {
            recipes.Clear();
            txtOutput.Clear();
            statusBarText.Text = "All recipes cleared.";
        }
    }
}